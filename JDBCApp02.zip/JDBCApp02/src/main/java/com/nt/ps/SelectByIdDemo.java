package com.nt.ps;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class SelectByIdDemo {
	public static void main( String[] args ) throws Exception {
		Scanner sc = new Scanner( System.in );
		System.out.println( "enter id here" );
		int enteredValue = sc.nextInt();
		Class.forName( "com.mysql.jdbc.Driver" );

		Connection con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/spti", "root", "root_1234" );

		PreparedStatement ps = con.prepareStatement( "select * from emp where id=?" );
		ps.setInt( 1, enteredValue );
		ResultSet rs = ps.executeQuery();

		if ( rs.next() ) {
			int id = rs.getInt( "id" );
			String name = rs.getString( "name" );
			int sal = rs.getInt( "sal" );
			System.out.println( id + " " + name + " " + sal );
		} else {
			System.out.println( "No record found!!!!" );
		}
		System.out.println( "finish" );
	}
}
