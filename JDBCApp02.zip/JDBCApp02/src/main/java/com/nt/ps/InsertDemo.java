package com.nt.ps;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class InsertDemo {
	public static void main( String[] args ) throws Exception {
		Class.forName( "com.mysql.jdbc.Driver" );
		Connection con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/spti", "root", "root_1234" );

		PreparedStatement ps = con.prepareStatement( "insert into emp values(?,?,?)" );

		ps.setInt( 1, 4 );
		ps.setString( 2, "Sameer" );
		ps.setInt( 3, 4000 );

		int result = ps.executeUpdate();

		System.out.println( result + " record inserted" );

		System.out.println( "finish" );
	}
}
