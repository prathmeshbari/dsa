package com.nt.ps;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SelectAllDemo {
	public static void main( String[] args ) throws Exception {
		Class.forName( "com.mysql.jdbc.Driver" );

		Connection con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/spti", "root", "root_1234" );

		PreparedStatement ps = con.prepareStatement( "select * from emp" );

		ResultSet rs = ps.executeQuery();

		while ( rs.next() ) {
			int id = rs.getInt( "id" );
			String name = rs.getString( "name" );
			int sal = rs.getInt( "sal" );
			System.out.println( id + " " + name + " " + sal );
		}
		System.out.println( "finish" );
	}
}
