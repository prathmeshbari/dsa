package com.nt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SelectByIdDemo {
	public static void main( String[] args ) throws Exception {
		//driver registration with DriverManager
		Class.forName( "com.mysql.jdbc.Driver" );

		//Connection creation
		Connection con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/spti", "root", "root_1234" );

		//Create truck or statement
		Statement st = con.createStatement();

		//add query into truck and send it for execution
		ResultSet rs = st.executeQuery( "select * from emp where id=10" );

		if ( rs.next() ) {
			int id = rs.getInt( "id" );
			String name = rs.getString( "name" );
			int sal = rs.getInt( "sal" );
			System.out.println( id + " " + name + " " + sal );
		} else {
			System.out.println( "No record found!!!!" );
		}
		System.out.println( "finish" );
	}
}
