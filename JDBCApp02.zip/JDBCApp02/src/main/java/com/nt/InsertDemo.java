package com.nt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class InsertDemo {
	public static void main( String[] args ) throws Exception {
		//driver registration with DriverManager
		Class.forName( "com.mysql.jdbc.Driver" );

		//Connection creation
		Connection con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/spti", "root", "root_1234" );

		//Create truck or statement
		Statement st = con.createStatement();

		//add query into truck and send it for execution
		int result = st.executeUpdate( "insert into emp(id,name,sal) values(3,'sam',3000)" );

		System.out.println( result + " record inserted" );

		//close the connection
		con.close();
		System.out.println( "finish" );
	}
}
