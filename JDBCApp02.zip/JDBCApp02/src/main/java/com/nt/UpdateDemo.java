package com.nt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class UpdateDemo {
	public static void main( String[] args ) throws Exception {
		//driver registration with DriverManager
		Class.forName( "com.mysql.jdbc.Driver" );

		//Connection creation
		Connection con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/spti", "root", "root_1234" );

		//Create truck or statement
		Statement st = con.createStatement();

		//add query into truck and send it for execution
		int result = st.executeUpdate( "update emp set sal=1001 where id=1" );

		System.out.println( result + " record updated" );

		//close the connection
		con.close();
		System.out.println( "finish" );
	}
}
